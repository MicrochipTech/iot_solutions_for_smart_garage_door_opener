/*******************************************************************************
  MAC HwdEnergyDetection Header File

  Company:
    Microchip Technology Inc.

  File Name:
    machwdEd.h

  Summary:
    This file contains the MACHWD energy detection types and function prototypes.

  Description:
    This file contains the MACHWD energy detection types and function prototypes.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2018 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END

#ifndef _MACHWDED_H
#define _MACHWDED_H

/******************************************************************************
                    Includes section
******************************************************************************/
#include <mac_phy/mac_hwd_phy/include/machwdService.h>

/******************************************************************************
                    Define(s) section
******************************************************************************/

/******************************************************************************
                    Types section
******************************************************************************/
//! MACHWD energy detection confirm structure.
typedef struct
{
  PHY_EnergyLevel_t energyLevel;
} MACHWD_EdConf_t;

//! MACHWD energy detection request structure.
typedef struct
{
  MACHWD_Service_t service;
  // Callback pointer.
  void (*MACHWD_EdConf)(MACHWD_EdConf_t *confParams);
  // Confirm parameters.
  MACHWD_EdConf_t confirm;
} MACHWD_EdReq_t;

/******************************************************************************
                    Prototypes section
******************************************************************************/
/**************************************************************************//**
  \brief Detects energy level on channel.
  \param reqParams - MACHWD energy detection request structure pointer.
  \return none.
******************************************************************************/
void MACHWD_EdReq(MACHWD_EdReq_t *reqParams);

#endif /* _MACHWDED_H */

// eof machwdEd.h
